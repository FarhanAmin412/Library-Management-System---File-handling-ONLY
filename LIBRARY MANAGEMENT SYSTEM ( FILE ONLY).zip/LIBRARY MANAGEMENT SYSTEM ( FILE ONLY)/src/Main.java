public class Main
{
    public static void main(String[] args) throws Exception {
        BookMenu menu = new BookMenu();
        menu.ImplementBookMenu();
    }
}
